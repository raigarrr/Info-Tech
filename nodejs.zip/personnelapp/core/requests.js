const pool = require('./pool');



function Request() {};

Request.prototype = {

    find : function(user = null, callback)
    {
        let sql = `SELECT * FROM personel_accounts WHERE username = ?`;


        pool.query(sql, user, function(err, result) {
            if(err) throw err

            if(result.length) {
                callback(result[0]);
            }else {
                callback(null);
            }
        });
    },


    login : function(username, password, callback)
    {
        this.find(username, function(user) {
            if(user) {
                
                if(password == user.password) {
                    callback(user);
                    return;
                }  
            }
            
            callback(null);
        });
    }
}



module.exports = User;
const pool = require('./pool');



function Update() {};

Update.prototype = {

    find : function(status = 'pending', callback)
    {
        let sql = `SELECT * FROM personel_accounts WHERE username = ?`;


        pool.query(sql, user, function(err, result) {
            if(err) throw err

            if(result.length) {
                callback(result[0]);
            }else {
                callback(null);
            }
        });
    },


    login : function(username, password, callback)
    {
        // find the user data by his username.
        this.find(username, function(user) {
            // if there is a user by this username.
            if(user) {
                // now we check his password.
                if(password == user.password) {
                    // return his data.
                    callback(user);
                    return;
                }  
            }
            // if the username/password is wrong then return null.
            callback(null);
        });
    }
}



module.exports = User;
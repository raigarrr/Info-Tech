-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 20, 2019 at 08:18 AM
-- Server version: 5.7.24
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtechlecture`
--

-- --------------------------------------------------------

--
-- Table structure for table `personel_accounts`
--

DROP TABLE IF EXISTS `personel_accounts`;
CREATE TABLE IF NOT EXISTS `personel_accounts` (
  `username` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `type` enum('Personel','None') NOT NULL DEFAULT 'Personel',
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personel_accounts`
--

INSERT INTO `personel_accounts` (`username`, `firstName`, `lastName`, `type`, `password`) VALUES
(1, 'juan', 'cruz', 'Personel', '123456789'),
(2, 'marikit', 'maganda', 'Personel', '987654321');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
CREATE TABLE IF NOT EXISTS `request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(45) NOT NULL,
  `tenantid` int(11) NOT NULL,
  `remarks` tinytext,
  `created_at` timestamp(2) NOT NULL DEFAULT CURRENT_TIMESTAMP(2) ON UPDATE CURRENT_TIMESTAMP(2),
  `status` enum('pending','scheduled','done') DEFAULT 'pending',
  `request` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `unit`, `tenantid`, `remarks`, `created_at`, `status`, `request`) VALUES
(2, 'F1-B', 2, '2019-12-17,ada', '2019-12-20 08:17:16.01', 'done', 'Broken lights'),
(4, 'F2-W', 8, NULL, '2019-12-13 09:56:41.57', 'pending', 'Door won\'t close'),
(1, 'F5-A', 1, NULL, '2019-12-20 06:43:25.42', 'pending', 'Broken Tiles'),
(3, 'F3-B', 2, NULL, '2019-12-20 06:43:25.42', 'pending', 'Window won\'t open'),
(5, 'F6-2', 3, '2019-12-25', '2019-12-20 06:51:20.05', 'scheduled', 'Door won\'t open');

-- --------------------------------------------------------

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
CREATE TABLE IF NOT EXISTS `tenant` (
  `idtenant` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `unit` varchar(45) NOT NULL,
  PRIMARY KEY (`idtenant`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenant`
--

INSERT INTO `tenant` (`idtenant`, `firstname`, `lastname`, `contact`, `unit`) VALUES
(1, 'Mario', 'Felipe', '09090808081', 'F1-A'),
(2, 'Lawrence', 'Bernardo', '09090808081', 'F1-A');

-- --------------------------------------------------------

--
-- Table structure for table `tenantinfo`
--

DROP TABLE IF EXISTS `tenantinfo`;
CREATE TABLE IF NOT EXISTS `tenantinfo` (
  `tenantID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pnumber` varchar(11) NOT NULL,
  `roomNumber` varchar(255) NOT NULL,
  PRIMARY KEY (`tenantID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tenantinfo`
--

INSERT INTO `tenantinfo` (`tenantID`, `firstName`, `lastName`, `address`, `email`, `pnumber`, `roomNumber`) VALUES
(1, 'Patrick', 'Responde', 'bukaneg street, legarda, baguio city', '2152751@slu.edu.ph', '1234567891', '211'),
(2, 'Jayditch', 'Balansi', 'Tuding, Baguio City', 'jayditch@email.com', '1987654321', '212'),
(3, 'Anne', 'Manahan', 'Goshen, Bakakeng, Baguio City', '2164165@slu.edu.ph', '1234569871', '213'),
(4, 'Destine', 'Aldana', 'San Luis Baguio City', 'aldana@email.com', '09123658746', '214'),
(5, 'Rico', 'Pangan', 'Baguio City', 'pangan@email.com', '09846325176', '215');

-- --------------------------------------------------------

--
-- Table structure for table `tenant_accounts`
--

DROP TABLE IF EXISTS `tenant_accounts`;
CREATE TABLE IF NOT EXISTS `tenant_accounts` (
  `tenantID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `roomNumber` varchar(11) NOT NULL,
  PRIMARY KEY (`tenantID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenant_accounts`
--

INSERT INTO `tenant_accounts` (`tenantID`, `firstName`, `lastName`, `roomNumber`) VALUES
(1, 'a', 'b2', '32'),
(2, 'guest', 'g', '45'),
(3, 'f', 'd', '45');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

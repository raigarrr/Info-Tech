const express = require('express');
var mysql = require('mysql');
const User = require('../core/user');
const router = express.Router();


function getMySQLConnection() {
	return mysql.createConnection({
	  host     : 'localhost',
	  user     : 'root',
	  password : '',
	  database : 'webtechlecture'
	});
}

const user = new User();
// get index page
router.get('/', (req, res, next) => {
    res.render('index', {title: "Log in"});
})


router.get('/home', function(req, res) {
	var requestList = [];
    

	var connection = getMySQLConnection();
	connection.connect();


	connection.query("SELECT id, unit, tenantid, remarks, created_at, status, request FROM request where status = 'pending'", function(err, rows, fields) {
        console.log('query done');  
        if (err) {
            console.log('error');
	  		res.status(500).json({"status_code": 500,"status_message": "internal server error"});
	  	} else {
            console.log('going loop');
	  		for (var i = 0; i < rows.length; i++) {


		  		var request = {
                    'id':rows[i].id,
                    'unit':rows[i].unit,
                    'tenantid':rows[i].tenantid,
                    'schedule':rows[i].schedule,
                    'created_at':rows[i].created_at,
                    'status':rows[i].status,
                    'request':rows[i].request,
                    
                  }
                console.log('request object created');
                  
                requestList.push(request);
                console.log('object added');
                  
	  	}
          res.render('request', {"requestList": requestList});
          console.log('rendered');
          
	  	}
	});
	connection.end();
	
});

router.get('/scheduled', function(req, res) {
	var requestList = [];
    

	var connection = getMySQLConnection();
	connection.connect();


	connection.query("SELECT id, unit, tenantid, remarks, created_at, status, request FROM request where status = 'scheduled'", function(err, rows, fields) {
        console.log('query done');  
        if (err) {
            console.log('error');
	  		res.status(500).json({"status_code": 500,"status_message": "internal server error"});
	  	} else {

            console.log('going loop');
	  		for (var i = 0; i < rows.length; i++) {


		  		var request = {
                    'id':rows[i].id,
                    'unit':rows[i].unit,
                    'tenantid':rows[i].tenantid,
                    'schedule':rows[i].schedule,
                    'created_at':rows[i].created_at,
                    'status':rows[i].status,
                    'request':rows[i].request,
                    
                  }
                console.log('request object created');
                  
                requestList.push(request);
                console.log('object added');
                  
	  	}
          res.render('scheduled', {"requestList": requestList});
          console.log('rendered');
          
	  	}
	});
	connection.end();
	
});

router.get('/archives', function(req, res) {
	var requestList = [];


	var connection = getMySQLConnection();
	connection.connect();


	connection.query("SELECT id, unit, tenantid, remarks, created_at, status, request FROM request where status = 'done'", function(err, rows, fields) {
        console.log('query done');  
        if (err) {
            console.log('error');
	  		res.status(500).json({"status_code": 500,"status_message": "internal server error"});
	  	} else {

            console.log('going loop');
	  		for (var i = 0; i < rows.length; i++) {


		  		var request = {
                    'id':rows[i].id,
                    'unit':rows[i].unit,
                    'tenantid':rows[i].tenantid,
                    'schedule':rows[i].schedule,
                    'created_at':rows[i].created_at,
                    'status':rows[i].status,
                    'request':rows[i].request,
                    
                  }
                console.log('request object created');

                requestList.push(request);
                console.log('object added');

	  	}
          res.render('archives', {"requestList": requestList});
          console.log('rendered');
          
	  	}
	});
	connection.end();
	
});

// Post
router.post('/login', (req, res, next) => {

    user.login(req.body.username, req.body.password, function(result) {
        if(result) {
            res.redirect('/home');
            console.log('going home');
           
        }else {
            
            res.send('Username/Password incorrect!');
        }
    })

});










module.exports = router;

